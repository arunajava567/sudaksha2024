export class Quarterinfo {
    public quater: string;
    public result:{
        sales:number;
        otherIncome:number;
        grossProfit:number;
        Depreciation:number;
        Interest:number;
        Tax:number;
        netProfit:number;
    }
}