import { CheckcasingPipe } from './checkcasing.pipe';

describe('CheckcasingPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckcasingPipe();
    expect(pipe).toBeTruthy();
  });
});
