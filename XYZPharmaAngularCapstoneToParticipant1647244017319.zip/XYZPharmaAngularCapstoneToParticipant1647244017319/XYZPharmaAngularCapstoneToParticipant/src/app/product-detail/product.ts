export class Product {
    public name: string;
    public saltCompostion: string;
    public about: string;
    public use: string;
    public sideEffects: string;
}