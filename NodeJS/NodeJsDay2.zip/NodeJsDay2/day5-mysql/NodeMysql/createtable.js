var mysql = require('mysql2');  
var con = mysql.createConnection({  
host: "localhost:3307",  
user: "root",  
password: "root",  
database: "lti1"  
});  
con.connect(function(err) {  
if (err) throw err;  
console.log("Connected!");  
var sql = "CREATE TABLE if not exists employeesinno (id INT, name VARCHAR(25), age INT(3), city VARCHAR(25))";  
con.query(sql, function (err, result) {  
if (err) throw err;  
console.log("Table created");  
});  
}); 