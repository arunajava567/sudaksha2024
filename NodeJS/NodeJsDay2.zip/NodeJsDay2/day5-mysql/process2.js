process.argv.forEach((value, index, array) => {  
  console.log(`${index}: ${value}`);  
});  