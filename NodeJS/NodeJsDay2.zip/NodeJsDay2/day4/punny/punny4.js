punycode = require('punycode');  
console.log(punycode.toUnicode('xn--maana-pta.com'));   