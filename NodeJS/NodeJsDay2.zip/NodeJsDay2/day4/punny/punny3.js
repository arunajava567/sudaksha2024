punycode = require('punycode');  
console.log(punycode.toASCII('ma�ana.com'));   