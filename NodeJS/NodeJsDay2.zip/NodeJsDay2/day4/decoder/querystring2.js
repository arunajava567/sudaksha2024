	querystring = require('querystring');  
	const qs1=querystring.stringify({name:'sonoo',company:'javatpoint'});  
console.log(qs1);  
