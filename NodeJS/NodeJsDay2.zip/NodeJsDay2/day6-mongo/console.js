console.log('This example is different!');
console.log('The result is displayed in the Command Line Interface');