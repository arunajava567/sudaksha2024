var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost/innovapptive';

MongoClient.connect(url, function(err, db) {

  

        console.log("connected");

  db.close();
});