const MongoClient = require('mongodb').MongoClient;

const url = 'mongodb://localhost:27017';

 function findOne() {

    const client =  MongoClient.connect(url, { useNewUrlParser: true })
        .catch(err => { console.log(err); });

    if (!client) {
        return;
    }

    try {

        const db = client.db("innovapptive");

        let collection = db.collection('course');

        let query = { name: 'angular' }

        let res = collection.findOne(query);

        console.log(res);

    } catch (err) {

        console.log(err);
    } finally {

        //client.close();
    }
}

 findOne();

