const { MongoClient } = require('mongodb');
const url = 'mongodb://localhost';
const client = new MongoClient(url);
const dbName = 'innovapptive';
// alternate to => with setTimeout()
async function main() {
  await client.connect();
  console.log('Connected successfully to server');
}

main()
  .then(console.log)
  .catch(console.err)
  .finally(() => client.close());