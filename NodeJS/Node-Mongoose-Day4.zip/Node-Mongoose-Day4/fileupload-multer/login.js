var http = require('http');
var formidable = require('formidable');

http.createServer(function (req, res) {
  if (req.url == '/login') {
    var form = new formidable.IncomingForm();
    form.parse(req, function (err, fields) {
      res.write('Login success');
      res.write(req.id);
    //  res.write(req.fields);


      res.end();
    });
  } else {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write('<form action="login" method="post">');
    res.write('<input type="text" name="id"><br>');
    res.write('<input type="password" name="pwd"><br>');

    res.write('<input type="submit">');
    res.write('</form>');
    return res.end();
  }
}).listen(8084);