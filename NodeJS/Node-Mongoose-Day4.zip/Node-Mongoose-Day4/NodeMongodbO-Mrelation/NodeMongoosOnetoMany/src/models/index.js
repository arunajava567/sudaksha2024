module.exports = {
  Tutorial: require("./Tutorial"),
  Image: require("./Image"),
  Comment: require("./Comment"),
  Category: require("./Category")
};
