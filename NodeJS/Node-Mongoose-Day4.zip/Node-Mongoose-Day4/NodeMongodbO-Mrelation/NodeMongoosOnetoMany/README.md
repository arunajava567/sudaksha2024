# MongoDB - Mongoose One-to-Many relationship example

For more detail, please visit:
> [Nodejs & MongoDb: One-to-Many relationship tutorial with Mongoose examples](https://bezkoder.com/mongoose-one-to-many-relationship/)

## Project setup
```
npm install
```

### Run
```
node src/server.js
```
