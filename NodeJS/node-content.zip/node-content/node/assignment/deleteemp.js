var express = require('express');
var app = express();
var fs = require('fs');
app.delete('/deleteEmployee/:id', function (req, res) {
console.log('delete');
   fs.readFile( __dirname + "/" + "employee.json", 'utf8', function (err, data) {
       var delEmp = "employee" + req.params.id;
       data = JSON.parse( data );
       console.log('data', data);
       delete data[delEmp];
       console.log('data', data);
       res.end( JSON.stringify(data));
   });
})

var server = app.listen(8000, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("app listening at ", host, port)
})