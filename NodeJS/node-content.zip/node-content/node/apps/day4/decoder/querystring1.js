	querystring = require('querystring');  
	const obj1=querystring.parse('name=sonoo&company=cts123');  
	console.log(obj1);  
