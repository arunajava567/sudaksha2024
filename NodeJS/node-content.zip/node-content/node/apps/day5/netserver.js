const net = require('net');  
var server = net.createServer((socket) => {  
  socket.end('goodbye\n');  
}).on('error', (err) => {  
  // handle errors here  
  throw err;  
}); 

server.on('data', (data) => {  
  console.log(data.toString());  
  //client.end();  
});   
// grab a random port.  
server.listen(() => {  
  address = server.address();  
  console.log('opened server on %j', address);  
});  