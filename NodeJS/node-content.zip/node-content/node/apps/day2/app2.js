var num = -2 
var result = num > 0 ?"positive":"non-positive" 
console.log(result)
console.log("running")
var x="ram"
console.log(typeof x)
var n = 1 
while(n < 10) { 
  
  if(n==5) {
    continue}
  console.log(n) 
   n++
} 
var i=10
console.log(" do while")
do { 
   console.log(i)
   i++ 
} 
while(i<=20)
