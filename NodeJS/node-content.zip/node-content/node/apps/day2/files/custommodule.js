var moduleFunction = require('./module.js');
// It is possible to use all of the export methods from the custom Module
moduleFunction();  //calling function
