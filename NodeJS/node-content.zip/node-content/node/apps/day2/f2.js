var msg : () -> "Welcome to Typescript"

console.log(msg())