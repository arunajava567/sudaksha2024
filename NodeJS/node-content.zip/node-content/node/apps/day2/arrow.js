var f1 = function (y)
{   return 20+y
}
var foo = (x)=>  10 + x   //lamda function arrow function
                
console.log(foo(100))   
console.log(foo(50))
console.log(f1(40))
