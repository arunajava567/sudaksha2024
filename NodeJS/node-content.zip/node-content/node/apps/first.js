



//console.log('Hello Welcome to CTS Node Js training');   

//var cname='Cognizant Technlogy Services'
//console.log('Hello %s', cname);   

//console.error(new Error('Hell! This is a wrong method.')); 
//console.log('Hello Welcome to CTS Node Js training'); 
//var address='Hyderabad'

//const name = 'John';  
//console.warn(`Don't mess with me ${name}! Don't mess with me!`);   
//console.log('Hello Welcome to CTS Node Js training'); 


// first node.js app

/*
  node training
  for 6 days

*/