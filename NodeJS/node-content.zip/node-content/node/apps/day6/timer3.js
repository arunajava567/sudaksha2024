setTimeout(function() {   
console.log("setTimeout: Hey! 1000 millisecond completed!..");  
}, 1000);  