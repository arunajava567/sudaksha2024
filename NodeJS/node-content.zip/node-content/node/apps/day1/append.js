var fs = require('fs');

fs.appendFile('one.html', 'Chennai-Hyderabad-Pune', function (err) {
  if (err) throw err;
  console.log('Saved!');
});
