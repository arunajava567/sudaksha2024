var fs = require('fs');

fs.unlink('one.html', function (err) {
  if (err) throw err;
  console.log('File deleted!');
});
