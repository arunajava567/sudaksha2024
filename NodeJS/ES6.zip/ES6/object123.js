
let emp={
    id:101,
    name:'raj',
    age:50,
    disp() {
        console.log(this.id+"  "+this.name+"  "+this.age);
    }
}

emp.disp();