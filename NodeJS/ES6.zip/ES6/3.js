(function()  
 {  
 console.log("Hello World");   
})();  

//(function(){ console.log("IIM function")} )()
(function(a,b){console.log(a)})(40,50)

var a1=new Array();
a1[0]=10
a1[2]=20
console.log(a1)

var a2=[6,7,8];
console.log(a2)