class Greeting
{

greet() : void {
    console.log("Welcome toTypescript");
}

}
//class definition

/*

object creation for a class

*/
var obj=new Greeting();

obj.greet();
