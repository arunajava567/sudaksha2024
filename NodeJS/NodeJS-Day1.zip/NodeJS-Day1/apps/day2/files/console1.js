

console.error(new Error('Hell! This is a wrong method.'));  