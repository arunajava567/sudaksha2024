
var moduleFunction = function(){
    console.log("CTS module is created...");
}

module.exports = moduleFunction;
