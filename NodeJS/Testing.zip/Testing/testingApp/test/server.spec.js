const { expect } = require('chai'); // Library to clean and easy syntax
const request = require('supertest'); //library for http agent
const app = require('../server')


describe('testing app get routing', () => {
    it('testing response for simple route', async() => {
        const res = await request(app).get('/')
        expect(res.body).to.equal('Hello World');
    });
    it('testing status code for simple route', async() => {
        const res = await request(app).get('/')
        expect(res.statusCode).to.equal(200);
    });
})


describe('testing app get route with params', () => {
    it('testing param route response with correct param', async() => {
        //creating a request
        const res = await request(app).get('/user/Vegeta')
            //Checking for response 
        expect(res.body).to.equal('Welcome Vegeta');
    });
    it('testing status code', async() => {
        const res = await request(app).get('/user/Vegeta')
        expect(res.statusCode).to.equal(200);
    });
    it('testing param route response with incorrect param', async() => {
        //creating a request
        const res = await request(app).get('/user/Goku')
            //Checking for response 
        expect(res.body).to.equal('Name Mismatch');
    });
    it('testing status code with incorrect params', async() => {
        const res = await request(app).get('/user/Goku')
        expect(res.statusCode).to.equal(404);
    });
})