const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.status(200);
    res.json('Hello World')
})

app.get('/user/:name', (req, res) => {
    try {
        if (req.params.name == 'Vegeta') {
            res.json(`Welcome ${req.params.name}`)
        } else {
            let err = new Error("Name Mismatch")
            err.status = 404;
            throw err;
        }
    } catch (err) {
        res.status(err.status)
        res.json(err.message)
    }
})

if (!module.parent) {
    app.listen(4050);
    console.log("Server listening in port 4000");
}
module.exports = app;