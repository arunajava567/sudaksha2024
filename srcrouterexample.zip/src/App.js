import React from 'react';
import {  Routes, Link, Route } from 'react-router-dom';
import About from './components/About';
import Home from './components/Home';
import Contact from './components/Contact';
import Form2 from './Form2'
import './style.css';
//npm install react-router-dom
export default function App() {
  return (
    // <Router>
      <div>
        <nav>
          <ul>
            <li>
             <Link to="/"><button>Home</button></Link> 
            </li>
            <li>
              <Link to="/about"><button>About</button></Link>
            </li>
            <li>
              <Link to="/contact"><button>Contact</button></Link>
            </li>
          </ul>
        </nav>

        <hr />
        <Routes>
          <Route exact path="/" element={<Home/>} />
          <Route path="/about" element={<About/>} />
          <Route path="/contact/:id" element={<Contact/>}/> 
        </Routes>
        <div>
          <Form2/>
        </div>
       
      </div>
      
    // </Router>
  );
}
/*http://localhost:3001/contact/123  */